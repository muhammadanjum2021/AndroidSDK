/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.database.Cursor;

import co.acoustic.mobile.push.sdk.api.db.SdkDatabaseCursor;


/**
 * This class is the loader of the inbox messages cursor
 */
public class RichInboxCursorLoader extends AsyncTaskLoader<SdkDatabaseCursor> {
   private SdkDatabaseCursor mCursor;

    /**
     * Creates a new loader with the application's context
     * @param context The application's context
     */
    public RichInboxCursorLoader(Context context)
    {
        super(context);
    }

    protected SdkDatabaseCursor loadCursor()
    {
        return RichContentDatabaseHelper.getRichContentDatabaseHelper(getContext()).getMessages();
    }

    /**
     * Loads the cursor in the background
     * @return The cursor
     */
    @Override
    public SdkDatabaseCursor loadInBackground()
    {
        SdkDatabaseCursor cursor = loadCursor();
        if(cursor != null)
            cursor.getCount();

        return cursor;
    }

    /**
     * Updates the loader with a new cursor
     * @param data The new cursor
     */
    @Override
    public void deliverResult(SdkDatabaseCursor data)
    {
        Cursor oldCursor = mCursor;
        mCursor = data;

        if(isStarted())
            super.deliverResult(data);

        if(oldCursor != null && oldCursor != data && !oldCursor.isClosed())
            oldCursor.close();
    }

    @Override
    protected void onStartLoading()
    {
        if(mCursor != null)
            deliverResult(mCursor);

        if(takeContentChanged() || mCursor == null)
            forceLoad();
    }

    @Override
    protected void onStopLoading()
    {
        cancelLoad();
    }

    /**
     * Called when loading is cancelred
     * @param cursor The cursor
     */
    @Override
    public void onCanceled(SdkDatabaseCursor cursor)
    {
        if(cursor != null && !cursor.isClosed())
            cursor.close();
    }

    @Override
    protected void onReset()
    {
        super.onReset();

        onStopLoading();

        if(mCursor != null && !mCursor.isClosed())
            mCursor.close();

        mCursor=null;
    }

}
