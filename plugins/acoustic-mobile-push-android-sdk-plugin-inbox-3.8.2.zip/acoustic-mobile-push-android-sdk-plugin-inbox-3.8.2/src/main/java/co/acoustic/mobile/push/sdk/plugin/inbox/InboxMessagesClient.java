/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.Context;
import android.content.Intent;

import co.acoustic.mobile.push.sdk.MceServerUrl;
import co.acoustic.mobile.push.sdk.api.Endpoint;
import co.acoustic.mobile.push.sdk.api.MceSdk;
import co.acoustic.mobile.push.sdk.api.OperationCallback;
import co.acoustic.mobile.push.sdk.api.OperationResult;
import co.acoustic.mobile.push.sdk.api.message.MessageSync;
import co.acoustic.mobile.push.sdk.api.registration.RegistrationDetails;;
import co.acoustic.mobile.push.sdk.plugin.Plugin;
import co.acoustic.mobile.push.sdk.plugin.PluginRegistry;
import co.acoustic.mobile.push.sdk.registration.PhoneHomeManager;
import co.acoustic.mobile.push.sdk.util.HttpHelper;
import co.acoustic.mobile.push.sdk.util.Iso8601;
import co.acoustic.mobile.push.sdk.util.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * This is the main API class for the inbox plugin
 */
public class InboxMessagesClient {

   public static final String INBOX_UPDATE_ACTION = "co.acoustic.mobile.push.sdk.plugin.inbox.UPDATE";

    private static final Executor EXECUTOR = Executors.newSingleThreadExecutor();
    static final InboxUpdatesState INBOX_UPDATE_STATE = new InboxUpdatesState();
    private static final String TAG = "InboxMessagesClient";

    /**
     * This status code will be returned if inbox sync fails because it was called less than min interval than the last sync.
     */
    public static final int SYNC_TOO_SOON_STATUS_CODE = 1001;

    /**
     * This status code will be returned if inbox sync fails because it was called more than the maximum times per day.
     */
    public static final int DAILY_SYNC_LIMIT_REACHED_STATUS_CODE = 1002;

    static class InboxSyncUrl extends MceServerUrl {

        static final String INBOX_PART = "inbox";
        static final String STATUS_PART = "status";

        public  final String getInboxUpdatesUrl(String baseUrl, Context context) {
            RegistrationDetails registrationDetails = MceSdk.getRegistrationClient().getRegistrationDetails(context);
            return buildURL(baseUrl, VERSION_PART, APPS_PART, MceSdk.getRegistrationClient().getAppKey(context), INBOX_PART, USERS_PART, registrationDetails.getUserId(), CHANNELS_PART, registrationDetails.getChannelId(), STATUS_PART);
        }

    }

    /**
     * Sets the message state as read.
     * @param context The application's context
     * @param message The message to set as read
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageRead(Context context, RichContent message) {
        return setMessageReadById(context, message.getMessageId());
    }

    /**
     * Sets the message state as read.
     * @param context The application's context
     * @param messageId The id of the message to set as read
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageReadById(Context context, String messageId) {
        int res = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageReadById(messageId);
        updateReadState(context, messageId, true);
        return res;
    }

    /**
     * Sets the message state as unread.
     * @param context The application's context
     * @param message The message to set as unread
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageUnread(Context context, RichContent message) {
        return setMessageUnreadById(context, message.getMessageId());
    }

    /**
     * Sets the message state as unread.
     * @param context The application's context
     * @param messageId The id of the message to set as unread
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageUnreadById(Context context, String messageId) {
        int res = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageUnreadById(messageId);
        updateReadState(context, messageId, false);
        return res;
    }

    /**
     * Delete a message by id
     * @param context The application's context
     * @param messageId The inbox message id
     * @return 1 for successful deletion, 0 for no deletion
     */
    public static long deleteMessageById(Context context, String messageId) {
        long res = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).deleteMessageById(messageId);
        updateDeleteState(context, messageId);
        return res;
    }

    /**
     * Deletes a message
     * @param context The application's context
     * @param message The message to delete
     * @return 1 for successful deletion, 0 for no deletion
     */
    public static long deleteMessage(Context context, RichContent message) {
        return deleteMessageById(context, message.getMessageId());
    }

    private static void updateReadState(final Context context, String messageId, boolean state) {
        sendUpdates(context, messageId, state, null);
    }

    private static void updateDeleteState(final Context context, String messageId) {
        sendUpdates(context, messageId, null, true);
    }

    private static String createUpdatePayload(String messageId, Boolean isRead, Boolean isDeleted) throws JSONException{
        JSONObject update = createUpdate(messageId, isRead, isDeleted);
        JSONArray updates = new JSONArray();
        updates.put(update);
        JSONObject payload = new JSONObject();
        payload.put("updates", updates);
        return payload.toString();
    }

    private static String addToUpdatePayload(String messageId, Boolean isRead, Boolean isDeleted, String updatePayload) throws JSONException {
        JSONObject update = createUpdate(messageId, isRead, isDeleted);
        JSONObject payloadJSON = new JSONObject(updatePayload);
        JSONArray updates = payloadJSON.getJSONArray("updates");
        updates.put(update);
        return payloadJSON.toString();
    }

    private static JSONObject createUpdate(String messageId, Boolean isRead, Boolean isDeleted) throws JSONException {
        JSONObject update = new JSONObject();
        update.put("inboxMessageId", messageId);
        update.put("timestamp", Iso8601.toString(new Date()));
        if(isRead != null) {
            update.put("isRead", isRead);
        }
        if(isDeleted != null) {
            update.put("isDeleted", isDeleted);
        }
        return update;
    }

    private static void sendUpdates(final Context context, String messageId, Boolean isRead, Boolean isDeleted) {
        INBOX_UPDATE_STATE.addUpdate(context, messageId, isRead, isDeleted);
    }

    /**
     * Retrieves a message by inbox message id
     * @param context The application's context
     * @param messageId The inbox message id
     * @return The message or null if no message with that inbox message id is found
     */
    public static RichContent getInboxMessageByMessageId(Context context, String messageId) {
        RichContentDatabaseHelper.MessageCursor cursor = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).getMessages();
        while (cursor.moveToNext()) {
            RichContent rc = cursor.getRichContent();
            if(rc.getMessageId().equals(messageId)) {
                return rc;
            }
        }
        return null;
    }

    /**
     * Retrieves a message by rich content id
     * @param context The application's context
     * @param contentId The rich content id
     * @return the latest message with the rich content id or null if no message with that rich content id is found
     */
    public static RichContent getInboxMessageByContentId(Context context, String contentId) {
        RichContentDatabaseHelper.MessageCursor cursor = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).getMessages();
        Date lastDate = new Date(0);
        RichContent lastMessage = null;
        while (cursor.moveToNext()) {
            RichContent rc = cursor.getRichContent();
            if(rc.getContentId().equals(contentId) && rc.getSendDate().after(lastDate)) {
                lastMessage = rc;
                lastDate = rc.getSendDate();
            }
        }
        return lastMessage;
    }

    /**
     * Synchronizes the inbox with the server and show the inbox once it's done
     * @param context The application's context
     */
    public static void showInbox(final Context context) {
        if(InboxMessageAction.richInboxActivity != null) {
            try {
                Intent intent = new Intent(context, InboxMessageAction.richInboxActivity);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Throwable t) {
                Logger.e(TAG, "Failed to show inbox", t);
            }
        }
    }

    static class InboxUpdatesState {
        private String updatePayload;
        private OperationCallback<String> callback;
        private Object handler;
        private boolean statusUpdateTaskPending;
        private Context context;

        public InboxUpdatesState() {
            handler = new Object();
            callback = new OperationCallback<String>() {
                @Override
                public void onSuccess(String messageId, OperationResult result) {

                }

                @Override
                public void onFailure(String messageId, OperationResult result) {
                    Logger.e(TAG, "Failed to update inbox state: " + updatePayload+" - "+result.getHttpResponse(), result.getError());
                }
            };
        }


        public synchronized void addUpdate(final Context context, String messageId, Boolean isRead, Boolean isDeleted) {
           try {
               updatePayload = InboxPreferences.getInboxStatusUpdatePayload(context);
                if (updatePayload == null) {
                    updatePayload = createUpdatePayload(messageId, isRead, isDeleted);
                    InboxPreferences.setInboxStatusUpdatePayload(context, updatePayload);
                    Logger.d(TAG,"Adding new inbox update: "+updatePayload);
                    this.context = context;
                    (new Thread() {
                        @Override
                        public void run() {
                            synchronized (handler) {
                                try {
                                    Logger.d(TAG,"Waiting for 2 seconds before sending update");
                                    handler.wait(2000L);
                                } catch (InterruptedException ie) {
                                }
                            }
                            Logger.d(TAG,"Sending update");
                            InboxUpdatesState.this.sendUpdatesThroughExecutor(context);
                        }
                    }).start();
                    statusUpdateTaskPending = true;
                } else {
                    Logger.d(TAG,"Updating inbox update: "+updatePayload+" with "+messageId+", "+isDeleted+", "+isDeleted);
                    updatePayload = addToUpdatePayload(messageId, isRead, isDeleted, updatePayload);
                    InboxPreferences.setInboxStatusUpdatePayload(context, updatePayload);
                    if(!statusUpdateTaskPending) {
                        InboxUpdatesState.this.sendUpdatesThroughExecutor(context);
                    }
                }
           } catch (JSONException jsone) {
               Logger.e(TAG, "Failed to add update: "+updatePayload, jsone);
               callback.onFailure(messageId, new OperationResult(false, null, jsone));
           }
        }

        void sendUpdatesThroughExecutor(final Context context) {
            Logger.d(TAG, "Inbox state update is called");
            EXECUTOR.execute(new Runnable() {
                @Override
                public void run() {
                    synchronized (InboxUpdatesState.this) {
                        try {
                            sendUpdates(context);
                        } catch (Throwable t) {
                            Logger.e(TAG, "Failed to send inbox status update", t);
                        }
                        statusUpdateTaskPending = false;
                    }
                }
            });
        }

        synchronized boolean sendUpdates(Context context) {
            updatePayload = InboxPreferences.getInboxStatusUpdatePayload(context);
            Logger.d(TAG, "Inbox state update is performed: "+updatePayload);
            if(updatePayload == null) {
                return true;
            }
            HttpHelper.Response response = null;
            try {

                String inboxUpdateUrl = new InboxSyncUrl().getInboxUpdatesUrl(Endpoint.getInstance().getBaseUrl(), context);
                response = HttpHelper.postJson(inboxUpdateUrl, updatePayload);
                if (response.getHttpResponseCode() == 202) {
                    Logger.d(TAG, "Successfully updated inbox: " + response.getResponseMessage());
                    if (callback != null) {
                        callback.onSuccess(null, new OperationResult(false, response, null));
                    }
                    updatePayload = null;
                    InboxPreferences.setInboxStatusUpdatePayload(context, null);
                    return true;
                } else {
                    Logger.e(TAG, "Failed updating inbox: " + response.getHttpResponseCode() + " " + response.getHttpResponseMessage());
                    if (callback != null) {
                        callback.onFailure(null, new OperationResult(false, response, null));
                    }
                    return false;
                }
            } catch (Exception e) {
                if (callback != null) {
                    callback.onFailure(null, new OperationResult(false, null, e));
                }
                Logger.e(TAG, "Failed to read messages", e);
                return false;
            }

        }
    }
}
