/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;


import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.Menu;
import android.view.MenuItem;

import co.acoustic.mobile.push.sdk.util.Logger;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;


/**
 * This is the display url activity. It contains a web view and 3 buttons: back, forward and done, which closes the activity.
 */
public class InboxMessageDisplayActivity extends InboxMessageActivity {

   private static final String  TAG = "InboxMessageDisplayActivity" ;

    private int actionDeleteId;
    private int actionNextId;
    private int actionPrevId;
    private int actionUnreadId;

    private List<RichContent> messages;
    private int currentIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        actionDeleteId = getResources().getIdentifier("action_delete", "id", getPackageName());
        actionNextId = getResources().getIdentifier("action_next", "id", getPackageName());
        actionPrevId = getResources().getIdentifier("action_prev", "id", getPackageName());
        actionUnreadId = getResources().getIdentifier("action_set_unread", "id", getPackageName());

        try {
            loadMessages();
            currentIndex = getIntent().getIntExtra("index", 0);
            activityId = getIntent().getLongExtra("activityId", 0);
            loadIndex(savedInstanceState);
        } catch (JSONException e) {
           Logger.e(TAG, "Failed to read messages", e);
        }



        super.onCreate(savedInstanceState);
        setupView();

    }



    private void loadMessages() throws JSONException {
        JSONArray messagesJSONArray = new JSONArray(getIntent().getStringExtra("messages"));
        messages = getInboxMessages(messagesJSONArray);
    }

    private void setupView() {
        RichContent currentMessage = messages.get(currentIndex);
        if(!currentMessage.getIsRead())
        {
            currentMessage.setIsRead(true);
            InboxMessagesClient.setMessageRead(getApplicationContext(), currentMessage);
        }
        RichContentTemplate template = RichContentTemplateRegistry.getRegisteredTemplate(currentMessage.getTemplate());
        template.getInboxMessageDisplay().displayMessage(currentMessage, this);
    }

    /**
     * This method inflates the menu
     * @param menu The menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        int menuId = getResources().getIdentifier("inbox_message_actions", "menu", getPackageName());
        getMenuInflater().inflate(menuId, menu);
        return true;
    }

    /**
     * This method handles a menu selection (back, forward or done).
     * @param item The selected menu item (back, forward or done).
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == actionDeleteId) {
            RichContent currentMessage = messages.get(currentIndex);
            if(InboxMessagesClient.deleteMessage(getApplicationContext(), currentMessage) > 0) {
                messages.remove(currentIndex);
                if(messages.isEmpty()) {
                    finish();
                } else {
                    currentIndex = currentIndex % messages.size();
                    setupView();
                }
            }
            return true;
        } else if (id == actionUnreadId) {
            RichContent currentMessage = messages.get(currentIndex);
            currentMessage.setIsRead(false);
            InboxMessagesClient.setMessageUnread(getApplicationContext(), currentMessage);
            return true;
        }else if (id == actionNextId) {
            currentIndex = (currentIndex + 1)%messages.size();
            setupView();
            return true;
        } else if (id == actionPrevId) {
            currentIndex = currentIndex - 1;
            if(currentIndex < 0) {
                currentIndex = messages.size()-1;
            }
            setupView();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public static JSONArray getInboxMessageAsJSONArray(List<RichContent> messages) throws JSONException{
        JSONArray messagesJSONArray = new JSONArray();
        int index = 0;
        for(RichContent rc : messages) {
            messagesJSONArray.put(index, RichContent.toJSON(rc));
            index++;
        }
        return messagesJSONArray;
    }

    private static List<RichContent> getInboxMessages(JSONArray inboxMessagesJSONArray) throws JSONException {
        List<RichContent> messages = new ArrayList<RichContent>(inboxMessagesJSONArray.length());
        for(int i =0 ; i < inboxMessagesJSONArray.length() ; ++i) {
            messages.add(RichContent.fromJSON(inboxMessagesJSONArray.getJSONObject(i)));
        }
        return messages;
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        loadIndex(savedInstanceState);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onRestoreInstanceState(savedInstanceState, persistentState);
        loadIndex(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        storeIndex(outState);
        setViewHidden();
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        storeIndex(outState);
        setViewHidden();
    }

    private void loadIndex(Bundle savedInstanceState) {
        if(savedInstanceState != null) {
            currentIndex = savedInstanceState.getInt("index", 0);
        }
    }

    private void storeIndex(Bundle outState) {
        outState.putInt("index", currentIndex);
    }

    private void setViewHidden() {
        RichContent currentMessage = messages.get(currentIndex);
        RichContentTemplate template = RichContentTemplateRegistry.getRegisteredTemplate(currentMessage.getTemplate());
        template.getInboxMessageDisplay().viewHidden(currentMessage, activityId);
    }
}