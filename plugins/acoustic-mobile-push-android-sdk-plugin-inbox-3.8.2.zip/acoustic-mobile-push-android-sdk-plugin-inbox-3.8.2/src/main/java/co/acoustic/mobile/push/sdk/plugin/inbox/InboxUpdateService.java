/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;
import android.os.SystemClock;

import co.acoustic.mobile.push.sdk.api.MceSdk;
import co.acoustic.mobile.push.sdk.api.OperationCallback;
import co.acoustic.mobile.push.sdk.api.OperationResult;
import co.acoustic.mobile.push.sdk.api.SdkState;
import co.acoustic.mobile.push.sdk.api.message.MessageProcessor;
import co.acoustic.mobile.push.sdk.api.message.MessageSync;
import co.acoustic.mobile.push.sdk.events.EventsTask;
import co.acoustic.mobile.push.sdk.task.MceSdkTaskScheduler;
import co.acoustic.mobile.push.sdk.util.Logger;
import co.acoustic.mobile.push.sdk.wi.AlarmScheduler;
import co.acoustic.mobile.push.sdk.wi.WakefulAlarmListener;

import java.util.List;
import java.util.Map;

/**
 * This class is the service that syncs the inbox db with the server
 */
public class InboxUpdateService extends WakefulAlarmListener {
   private static final String TAG =  "InboxUpdateService";

    private final long schedulingInterval;

    public InboxUpdateService() {
        super(InboxUpdateService.class.getName());
        schedulingInterval = 12L*60L*60L*1000L;
    }

    /**
     * This method is called when the inbox needs to be synced
     * @param context The application's context
     * @param extra No extra is required here
     */
    @Override
    public void onWakefulTrigger(Context context, Map<String, String> extra) {
        SdkState sdkState = MceSdk.getRegistrationClient().getSdkState(context);
        if(SdkState.REGISTERED.equals(sdkState)) {
            runInboxUpdate(context);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Logger.d(TAG, "Inbox update service called on OS level " + Build.VERSION.SDK_INT + ". Reverting to job");
                MceSdkTaskScheduler.startRepeatingTask(context, EventsTask.getInstance(), null, false);
                AlarmScheduler alarmScheduler = new AlarmScheduler(context);
                alarmScheduler.cancel(context, this);
            }
        }
    }

    static void runInboxUpdate(Context context) {
        synchronized (context) {
            MessageSync.syncMessages(context, new OperationCallback<MessageSync.SyncReport>() {
                @Override
                public void onSuccess(MessageSync.SyncReport syncReport, OperationResult result) {
                    InboxMessageProcessor.Report report = null;
                    for(MessageProcessor.ProcessReport processReport: syncReport.getReports()) {
                        if(processReport instanceof InboxMessageProcessor.Report) {
                            report = (InboxMessageProcessor.Report)processReport;
                        }
                    }
                    Logger.d(TAG, "Inbox update service got "+(report != null ? report.getNewMessages().size() : 0)+" new messages");
                }

                @Override
                public void onFailure(MessageSync.SyncReport syncReport, OperationResult result) {
                    Logger.e(TAG,"Inbox update service failed", (result != null ?result.getError() : null));
                }
            });
        }
    }

    /**
     * This method schedules the inbox sync operation
     * @param context The application's context
     * @param mgr The system alarm manager
     * @param pi The invoked pending intent
     * @param sceduleNow true for schedule to run immediately and false otherwise
     */
    @Override
    public void scheduleAlarms(Context context, AlarmManager mgr, PendingIntent pi, boolean sceduleNow) {
        mgr.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime(),
                schedulingInterval, pi);
        Logger.d(TAG, "Inbox update service was scheduled with interval " + schedulingInterval);
    }

    /**
     * This method retrieves the max age of this service
     * @param context The application's context
     * @return The max age
     */
    @Override
    public long getMaxAge(Context context) {
        return schedulingInterval;
    }

    @Override
    public Class getJobClass(Context context) {
        return InboxUpdateJob.class;
    }

    static void cancel(Context context) {
        AlarmScheduler alarmScheduler = new AlarmScheduler(context);
        alarmScheduler.cancel(context, new InboxUpdateService());
    }

}
